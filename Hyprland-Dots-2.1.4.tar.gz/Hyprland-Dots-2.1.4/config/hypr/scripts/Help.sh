#!/bin/bash

mousepad ~/.config/hypr/HelpFile.md
