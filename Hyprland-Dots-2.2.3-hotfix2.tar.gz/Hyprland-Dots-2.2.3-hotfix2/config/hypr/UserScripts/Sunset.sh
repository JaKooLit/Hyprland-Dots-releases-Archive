#!/bin/bash
## /* ---- 💫 https://github.com/JaKooLit 💫 ---- */  ##

# wlsunset project page
# https://sr.ht/~kennylevinsen/wlsunset/

wlsunset -t 4000 -T 6500 -d 900 -S 07:00 -s 19:00