###This will search as a quick tips / guide

### Rofi-Beats (online music)
- inorder to use this feature, you need to install yt-dlp or youtube-dl and of course mpv. By default mpv is only installed

### Waybar ricing
- 4 waybar hyprland/workspaces to choose from. Circle 
Roman Number, pacman, and workspace number and icons. Just assign accordingly on waybar configs. They are called hyprland/workspaces, #2, #3, #4 etc...